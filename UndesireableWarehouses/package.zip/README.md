The Undesireable Storage mod sets storage buildings to automatically disallow all goods inside them, as well as setting the building to 'emptying' for a visual cue when it is built.

This includes warehouses, water tanks, and any other storage building.  


---

Works in latest version of Experimental Branch.  

## 1.0.1
- Fixed crash that had to deal with beaver emptying behaviour. 