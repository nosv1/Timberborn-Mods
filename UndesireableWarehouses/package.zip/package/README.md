The Undesireable Storage mod sets storage buildings to automatically disallow all goods inside them, as well as setting the building to 'emptying' for a visual cue when it is built.

This includes warehouses, water tanks, and any other storage building.