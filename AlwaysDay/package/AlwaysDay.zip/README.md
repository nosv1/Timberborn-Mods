Mod to disable the visual day-night cycle.  
Beavers will behave normally.